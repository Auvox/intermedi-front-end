import PersonaAvatar from "../components/PersonaAvatar";
import { CartaoPessoa, GradePessoas } from "../components/Directory";
import { useCallback, useEffect, useRef, useState } from "react";
import useAcaoDaUrl from "../hooks/useAcaoDaUrl";
import { Link, Outlet, useLocation, useOutletContext } from "react-router-dom";
import ManagerSidebar from "../components/ManagerSidebar";
import PerfilProvider from "../components/perfil/PerfilProvider";
import { usePerfil } from "../components/perfil/perfilContext";
import { propsLinha } from "../services/perfil";
import { useAoAlterarDados } from "../hooks/useResumo";
import PersonaIcon from "../components/PersonaIcon";
import FarmaciaSelect from "../components/FarmaciaSelect";
import { buscarCep, digitosCep, formatarCep } from "../services/cep";
import SinoAlertas from "../components/desempenho/SinoAlertas";
import { ToastRegion } from "../components/Chamados";
import { useAlertas } from "../hooks/useAlertas";
import { useToast } from "../hooks/useChamados";
import {
  API_URL,
  listarFarmacias,
  listarFuncionarios,
  listarGerentes,
  listarPacientes,
  fotoPessoa,
} from "../services/api";
import { normalizeGerentes } from "../services/gerenteMapper";
import { aoMudarToken, nomeAdmin } from "../services/desempenho";
import { primeiroNome } from "../services/nomes";
import { initialData, unit, formatDate } from "./managerData";
import "../styles/manager.css";
import "../styles/managerRefresh.css";
import "../styles/admin.css";

// UI fixtures only: no API, authentication, persistence or server permissions.
const demoData = {
  gerentes: [
    {
      id: "g1",
      name: "Renata Lima",
      email: "renata@example.com",
      unit,
      status: "Ativo",
    },
    {
      id: "g2",
      name: "Paulo Martins",
      email: "paulo@example.com",
      unit: "Farmácia Jardim",
      status: "Ativo",
    },
  ],
  farmacias: [
    {
      id: "f1",
      name: "Farmácia Central",
      email: "central@intermedi.com",
      unit: "Farmácia Central",
      status: "Ativo",
    },
    {
      id: "f2",
      name: "Farmácia Jardim",
      email: "jardim@intermedi.com",
      unit: "Farmácia Jardim",
      status: "Ativo",
    },
    {
      id: "f3",
      name: "Farmácia Vila Verde",
      email: "vilaverde@intermedi.com",
      unit: "Farmácia Vila Verde",
      status: "Ativo",
    },
  ],
  pacientes: initialData.patients.map((person) => ({
    ...person,
    unit,
    status: "Ativo",
  })),
  chamados: initialData.tickets.map((ticket) => ({
    ...ticket,
    name: ticket.title,
  })),
};
const sections = {
  gerentes: {
    label: "Gerentes",
    title: "Gerentes",
    description: "Responsáveis por cada farmácia da rede.",
    action: "Excluir gerente",
    result: "excluído",
  },
  farmacias: {
    label: "Farmácias",
    title: "Farmácias",
    description: "Farmácias cadastradas na rede, com contato e endereço.",
    action: "Excluir farmácia",
    result: "excluída",
  },
  pacientes: {
    label: "Pacientes",
    title: "Pacientes",
    description: "Pacientes cadastrados na plataforma.",
    action: "Bloquear paciente",
    result: "bloqueado",
  },
  chamados: {
    label: "Solicitações",
    title: "Solicitações",
    description: "Pedidos de reposição abertos pelas equipes das farmácias.",
    action: "Banir chamado",
    result: "banido",
  },
};
const normalize = (value) =>
  value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();


const normalizeFarmacias = (payload = []) =>
  payload.map((farmacia, index) => {
    const id = farmacia.idFarmacia ?? farmacia.id ?? String(index + 1);
    const name =
      farmacia.nomeFarmacia ??
      farmacia.name ??
      farmacia.nome ??
      "Farmácia sem nome";
    const email = farmacia.emailFarmacia ?? farmacia.email ?? "";
    const phone = farmacia.telFarmacia ?? farmacia.telefone ?? "";
    const cnes = farmacia.cnesFarmacia ?? farmacia.cnes ?? "";
    const unit =
      farmacia.cidadeFarmacia ??
      farmacia.enderecoFarmacia ??
      farmacia.bairroFarmacia ??
      farmacia.unidade ??
      farmacia.unit ??
      "Unidade não informada";

    return {
      id: String(id),
      name,
      email,
      phone,
      cnes,
      photo: fotoPessoa(farmacia.fotoFarmacia),
      idEndereco: farmacia.idEndereco ?? null,
      unit,
      status: "Ativo",
      cepFarmacia: farmacia.cepFarmacia ?? farmacia.cep ?? "",
      enderecoFarmacia: farmacia.enderecoFarmacia ?? farmacia.endereco ?? "",
      numeroFarmacia: farmacia.numeroFarmacia ?? farmacia.numero ?? "",
      complementoFarmacia:
        farmacia.complementoFarmacia ?? farmacia.complemento ?? "",
      bairroFarmacia: farmacia.bairroFarmacia ?? farmacia.bairro ?? "",
      cidadeFarmacia: farmacia.cidadeFarmacia ?? farmacia.cidade ?? "",
      ufFarmacia: farmacia.ufFarmacia ?? farmacia.estadoFarmacia ?? "",
    };
  });

const normalizePacientes = (payload = []) =>
  payload.map((paciente, index) => {
    const id = paciente.idPaciente ?? paciente.id ?? String(index + 1);
    const name =
      paciente.nomePaciente ??
      paciente.name ??
      paciente.nome ??
      "Paciente sem nome";
    const email = paciente.emailPaciente ?? paciente.email ?? "";
    const unit =
      paciente.unidade ??
      paciente.unit ??
      paciente.cidadePaciente ??
      paciente.enderecoPaciente ??
      paciente.bairroPaciente ??
      "Unidade não informada";

    return {
      id: String(id),
      name,
      email,
      unit,
      photo: fotoPessoa(paciente.fotoPerfilPaciente) ?? paciente.photo,
      status: paciente.status || "Ativo",
      createdAt: paciente.createdAt ?? paciente.created_at ?? null,
      role: paciente.role ?? "Paciente",
      phone:
        paciente.telefonePaciente ?? paciente.phone ?? paciente.telefone ?? "",
    };
  });

const normalizeFuncionarios = (payload = []) =>
  payload.map((funcionario, index) => {
    const id = funcionario.idFuncionario ?? funcionario.id ?? String(index + 1);
    const name =
      funcionario.nomeFuncionario ??
      funcionario.name ??
      funcionario.nome ??
      "Funcionário sem nome";
    const email = funcionario.emailFuncionario ?? funcionario.email ?? "";
    const unit =
      funcionario.unidade ??
      funcionario.unit ??
      funcionario.unidadeFuncionario ??
      funcionario.farmacia ??
      funcionario.nomeFarmacia ??
      funcionario.fkIdFarmacia ??
      "Unidade não informada";

    return {
      id: String(id),
      name,
      email,
      unit,
      photo: fotoPessoa(funcionario.fotoFuncionario ?? funcionario.fotoPerfilFuncionario) ?? funcionario.photo,
      role: funcionario.cargoFuncionario ?? funcionario.role ?? "Funcionario",
      shift: funcionario.turnoFuncionario ?? funcionario.shift ?? "",
      status: "Ativo",
      phone: funcionario.telFuncionario ?? funcionario.phone ?? "",
      matricula:
        funcionario.matriculaFuncionario ?? funcionario.matricula ?? "",
      farmaciaId: funcionario.fkIdFarmacia ?? funcionario.idFarmacia ?? null,
    };
  });

// Apenas rotulo visual da trilha no topo (nao altera rotas nem dados).
const breadcrumbLabels = {
  medicamentos: "Medicamentos",
  gerentes: "Gerentes",
  farmacias: "Farmácias",
  pacientes: "Pacientes",
  chamados: "Solicitações",
  desempenho: "Desempenho",
};

function Icon({ name, size = 17 }) {
  const paths = {
    pharmacy: <><rect x="4" y="3" width="16" height="18" rx="3" /><path d="M12 6v6m-3-3h6M10 21v-5h4v5" /></>,
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-3.4-3.4" />
      </>
    ),
    bell: (
      <path d="M18 8a6 6 0 1 0-12 0c0 6-2.5 7.5-2.5 7.5h17S18 14 18 8ZM13.7 19a2 2 0 0 1-3.4 0" />
    ),
    chevronDown: <path d="m6 9 6 6 6-6" />,
    sliders: (
      <>
        <path d="M4 6h10m4 0h2M4 12h4m4 0h10M4 18h14m4 0h-2" />
        <circle cx="16" cy="6" r="2" />
        <circle cx="10" cy="12" r="2" />
        <circle cx="20" cy="18" r="2" />
      </>
    ),
    refresh: (
      <path d="M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5" />
    ),
    dots: (
      <>
        <circle cx="5" cy="12" r="1.6" />
        <circle cx="12" cy="12" r="1.6" />
        <circle cx="19" cy="12" r="1.6" />
      </>
    ),
    download: (
      <path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14" />
    ),
    chevronLeft: <path d="m14 6-6 6 6 6" />,
    chevronRight: <path d="m10 6 6 6-6 6" />,
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

export default function Admin() {
  const [data, setData] = useState(demoData);
  const { pathname } = useLocation();
  const currentSection = pathname.replace(/^\/admin\/?/, "").split("/")[0];
  const currentLabel = breadcrumbLabels[currentSection] || "Visão geral";
  // alertas da saúde do sistema: sino, aviso na hora (toast) e a aba Desempenho
  const [toast, notify] = useToast(10000);
  const alertas = useAlertas({ onCritico: (alerta) => notify(`Alerta crítico: ${alerta.titulo}`) });
  // nome de quem entrou como admin (some ao sair)
  const [adminName, setAdminName] = useState(nomeAdmin);
  useEffect(() => aoMudarToken(() => setAdminName(nomeAdmin())), []);
  useEffect(() => {
    document.title = "Área do admin | Intermedi";
    return () => {
      document.title = "Intermedi";
    };
  }, []);
  return (
    <div className="mgr-shell adm-shell">
      <ManagerSidebar admin unitName="Rede Intermedi" />
      <div className="mgr-workspace">
        <div className="mgr-topbar">
          <span>
            <span className="mgr-topbar-unit-prefix">
              Painel de administração
            </span>{" "}
            <span className="mgr-topbar-divider">/</span>{" "}
            <strong>{currentLabel}</strong>
          </span>
          <div className="mgr-account adm-account">
            <SinoAlertas alertas={alertas} />
            <PersonaAvatar className="mgr-account-avatar" role="admin" />
            <span className="mgr-account-person">
              <strong>{primeiroNome(adminName, "Admin")}</strong>
              <small>Administrador da plataforma</small>
            </span>
            <Link className="account-action account-exit" to="/login?perfil=admin">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M9 4H4v16h5M10 12h11m-4-4 4 4-4 4" /></svg>
              Sair
            </Link>
          </div>
        </div>
        <PerfilProvider plataforma="admin">
          <main id="conteudo" tabIndex={-1} className="mgr-main">
            <Outlet context={{ data, setData, alertas }} />
          </main>
        </PerfilProvider>
        <footer className="mgr-footer">
          Intermedi <span>Conectando farmácias. Aproximando o cuidado.</span>
        </footer>
      </div>
      <ToastRegion message={toast} />
    </div>
  );
}

function Dialog({ title, onClose, children }) {
  const ref = useRef(null);
  useEffect(() => {
    const previous = document.activeElement;
    const dialog = ref.current;
    dialog.showModal();
    return () => {
      dialog.close();
      previous?.focus();
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className="mgr-modal adm-dialog"
      aria-label={title}
      onCancel={onClose}
    >
      <div className="mgr-modal-head">
        <h2>{title}</h2>
        <button type="button" onClick={onClose} aria-label="Fechar janela">
          ×
        </button>
      </div>
      {children}
    </dialog>
  );
}

export function AdminDirectory({ section }) {
  const { data, setData } = useOutletContext();
  const { abrirPerfil } = usePerfil();
  // foto trocada no perfil: recarrega as listas para mostrar a nova
  const [versao, setVersao] = useState(0);
  useAoAlterarDados(() => setVersao((v) => v + 1));
  const tipoPerfil = section === "gerentes" ? "gerente" : section === "farmacias" ? "farmacia" : section === "pacientes" ? "paciente" : null;
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [unitFilter, setUnitFilter] = useState("");
  const [page, setPage] = useState(1);
  const [openRowMenu, setOpenRowMenu] = useState(null);
  const [modal, setModal] = useState(null);
  const [notice, setNotice] = useState("");
  const config = sections[section];
  const records = data[section];
  const tickets = section === "chamados";
  const managers = section === "gerentes";
  const pharmacies = section === "farmacias";
  const patients = section === "pacientes";
  const crud = managers || pharmacies || patients;
  // atalhos "Cadastrar gerente/farmácia" da visão geral
  useAcaoDaUrl(
    "cadastrar",
    useCallback(() => setModal({ type: managers ? "register" : "registerFarmacia" }), [managers]),
    managers || pharmacies,
  );
  const pageSize = 8;

  useEffect(() => {
    setPage(1);
    setOpenRowMenu(null);
  }, [search, status, unitFilter, section]);

  useEffect(() => {
    if (section !== "gerentes" && section !== "farmacias") {
      return undefined;
    }

    let cancelled = false;

    async function loadGerentes() {
      try {
        const rawList = await listarGerentes();

        if (!cancelled) {
          setData((current) => ({
            ...current,
            gerentes: normalizeGerentes(rawList),
          }));
        }
      } catch (error) {
        console.error("Erro ao carregar gerentes:", error);
        if (!cancelled) {
          setNotice("Não foi possível buscar os gerentes do endpoint.");
        }
      }
    }

    loadGerentes();

    return () => {
      cancelled = true;
    };
  }, [section, setData, versao]);

  useEffect(() => {
    if (section !== "farmacias" && section !== "gerentes") {
      return undefined;
    }

    let cancelled = false;

    async function loadFarmacias() {
      try {
        const rawList = await listarFarmacias();

        if (!cancelled) {
          setData((current) => ({
            ...current,
            farmacias: normalizeFarmacias(rawList),
          }));
        }
      } catch (error) {
        console.error("Erro ao carregar farmácias:", error);
        if (!cancelled) {
          setNotice("Não foi possível buscar as farmácias do endpoint.");
        }
      }
    }

    loadFarmacias();

    return () => {
      cancelled = true;
    };
  }, [section, setData, versao]);

  useEffect(() => {
    let cancelled = false;

    async function loadFuncionarios() {
      try {
        const rawList = await listarFuncionarios();

        if (!cancelled) {
          setData((current) => ({
            ...current,
            funcionarios: normalizeFuncionarios(rawList),
          }));
        }
      } catch (error) {
        console.error("Erro ao carregar funcionários:", error);
        if (!cancelled) {
          setNotice("Não foi possível buscar os funcionários do endpoint.");
        }
      }
    }

    loadFuncionarios();

    return () => {
      cancelled = true;
    };
  }, [setData, versao]);

  useEffect(() => {
    if (section !== "pacientes") {
      return undefined;
    }

    let cancelled = false;

    async function loadPacientes() {
      try {
        const rawList = await listarPacientes();

        if (!cancelled) {
          setData((current) => ({
            ...current,
            pacientes: normalizePacientes(rawList),
          }));
        }
      } catch (error) {
        console.error("Erro ao carregar pacientes:", error);
        if (!cancelled) {
          setNotice("Não foi possível buscar os pacientes do endpoint.");
        }
      }
    }

    loadPacientes();

    return () => {
      cancelled = true;
    };
  }, [section, setData, versao]);

  const [nomeGerente, setNomeGerente] = useState("");
  const [emailGerente, setEmailGerente] = useState("");
  const [cpfGerente, setCpfGerente] = useState("");
  const [crfGerente, setCrfGerente] = useState("");
  const [cepGerente, setCepGerente] = useState("");
  // "", "buscando", "nao-encontrado" ou "erro"
  const [statusCepGerente, setStatusCepGerente] = useState("");
  const buscaCepGerente = useRef(null);
  const numeroGerenteRef = useRef(null);
  const [enderecoGerente, setEnderecoGerente] = useState("");
  const [numeroGerente, setNumeroGerente] = useState("");
  const [complementoGerente, setComplementoGerente] = useState("");
  const [bairroGerente, setBairroGerente] = useState("");
  const [cidadeGerente, setCidadeGerente] = useState("");
  const [ufGerente, setUfGerente] = useState("");
  const [farmaciaGerente, setFarmaciaGerente] = useState(null);
  const [cadastrandoGerente, setCadastrandoGerente] = useState(false);
  const [erroCadastroGerente, setErroCadastroGerente] = useState("");

  const [nomeFarmacia, setNomeFarmacia] = useState("");
  const [emailFarmacia, setEmailFarmacia] = useState("");
  const [telFarmacia, setTelFarmacia] = useState("");
  const [cnesFarmacia, setCnesFarmacia] = useState("");
  const [cepFarmacia, setCepFarmacia] = useState("");
  const [enderecoFarmacia, setEnderecoFarmacia] = useState("");
  const [numeroFarmacia, setNumeroFarmacia] = useState("");
  const [complementoFarmacia, setComplementoFarmacia] = useState("");
  const [bairroFarmacia, setBairroFarmacia] = useState("");
  const [cidadeFarmacia, setCidadeFarmacia] = useState("");
  const [ufFarmacia, setUfFarmacia] = useState("");

  const filtered = records.filter(
    (record) =>
      normalize(`${record.name} ${record.unit} ${record.email || ""}`).includes(
        normalize(search.trim()),
      ) &&
      (!status || record.status === status) &&
      (!unitFilter || record.unit === unitFilter),
  );
  const restricted = records.filter((record) =>
    ["Bloqueado", "Banido"].includes(record.status),
  ).length;
  const activeCount = records.filter((record) => record.status === "Ativo")
    .length;
  const unitOptions = Array.from(
    new Set((records || []).map((record) => record.unit).filter(Boolean)),
  ).sort((a, b) => a.localeCompare(b, "pt-BR"));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginated = crud
    ? filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)
    : filtered;
  const pageStart = filtered.length ? (currentPage - 1) * pageSize + 1 : 0;
  const pageEnd = Math.min(filtered.length, currentPage * pageSize);

  function exportCsv() {
    const header = ["Nome", "Unidade", "Situação"];
    const rows = filtered.map((record) => [
      record.name,
      record.unit,
      record.status,
    ]);
    const csv = [header, ...rows]
      .map((row) =>
        row
          .map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`)
          .join(";"),
      )
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${section}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }

  const managerFarmacias = (data.farmacias || []).filter(
    (farmacia) => String(farmacia.id) === String(modal?.record?.farmaciaId),
  );

  const managerFuncionarios = (data.funcionarios || []).filter((funcionario) =>
    managerFarmacias.some((farmacia) => {
      const funcionarioFarmaciaId = String(
        funcionario.farmaciaId ??
          funcionario.idFarmacia ??
          funcionario.fkIdFarmacia ??
          funcionario.idFarmacia ??
          "",
      );
      return funcionarioFarmaciaId === String(farmacia.id);
    }),
  );

  async function confirmAction() {
    const record = modal.record;

    if (managers) {
      try {
        const response = await fetch(
          `${API_URL}/gerente/${encodeURIComponent(record.id)}`,
          {
            method: "DELETE",
            headers: {
              Accept: "application/json",
            },
          },
        );

        if (!response.ok) {
          const errorPayload = await response.json().catch(() => ({}));
          throw new Error(
            errorPayload.message ||
              errorPayload.error ||
              "Erro ao excluir gerente",
          );
        }

        setData((current) => ({
          ...current,
          gerentes: current.gerentes.filter((item) => item.id !== record.id),
        }));

        setNotice(`${record.name}: excluído com sucesso no banco.`);
        setModal(null);
        return;
      } catch (error) {
        console.error("Erro ao excluir gerente:", error);
        setNotice(error.message || "Erro ao excluir gerente.");
        setModal(null);
        return;
      }
    }

    if (pharmacies) {
      try {
        const response = await fetch(
          `${API_URL}/farmacia/${encodeURIComponent(record.id)}`,
          {
            method: "DELETE",
            headers: {
              Accept: "application/json",
            },
          },
        );

        if (!response.ok) {
          const errorPayload = await response.json().catch(() => ({}));
          throw new Error(
            errorPayload.message ||
              errorPayload.error ||
              "Erro ao excluir farmácia",
          );
        }

        setData((current) => ({
          ...current,
          farmacias: current.farmacias.filter((item) => item.id !== record.id),
        }));

        setNotice(`${record.name}: excluída com sucesso no banco.`);
        setModal(null);
        return;
      } catch (error) {
        console.error("Erro ao excluir farmácia:", error);
        setNotice(error.message || "Erro ao excluir farmácia.");
        setModal(null);
        return;
      }
    }

    if (patients) {
      try {
        const response = await fetch(
          `${API_URL}/paciente/${encodeURIComponent(record.id)}`,
          {
            method: "DELETE",
            headers: {
              Accept: "application/json",
            },
          },
        );

        if (!response.ok) {
          const errorPayload = await response.json().catch(() => ({}));
          throw new Error(
            errorPayload.message ||
              errorPayload.error ||
              "Erro ao excluir paciente",
          );
        }

        setData((current) => ({
          ...current,
          pacientes: current.pacientes.filter((item) => item.id !== record.id),
        }));

        setNotice(`${record.name}: removido com sucesso no banco.`);
        setModal(null);
        return;
      } catch (error) {
        console.error("Erro ao excluir paciente:", error);
        setNotice(error.message || "Erro ao excluir paciente.");
        setModal(null);
        return;
      }
    }

    setData((current) => ({
      ...current,
      [section]: current[section].map((item) =>
        item.id === record.id
          ? { ...item, status: tickets ? "Banido" : "Bloqueado" }
          : item,
      ),
    }));
    setNotice(`${record.name}: ${config.result} nesta demonstração.`);
    setModal(null);
  }
  // com os 8 dígitos do CEP, preenche endereço, bairro, cidade e UF pelo ViaCEP
  async function alterarCepGerente(texto) {
    setCepGerente(formatarCep(texto));
    buscaCepGerente.current?.abort();
    setStatusCepGerente("");
    if (digitosCep(texto).length !== 8) return;

    const controller = new AbortController();
    buscaCepGerente.current = controller;
    setStatusCepGerente("buscando");
    try {
      const endereco = await buscarCep(texto, { signal: controller.signal });
      if (controller.signal.aborted) return;
      if (!endereco) {
        setStatusCepGerente("nao-encontrado");
        return;
      }
      // CEP de cidade inteira vem sem rua e bairro: mantém o que já foi digitado
      if (endereco.endereco) setEnderecoGerente(endereco.endereco);
      if (endereco.bairro) setBairroGerente(endereco.bairro);
      setCidadeGerente(endereco.cidade);
      setUfGerente(endereco.uf);
      setStatusCepGerente("");
      numeroGerenteRef.current?.focus();
    } catch {
      if (!controller.signal.aborted) setStatusCepGerente("erro");
    }
  }

  async function register(event) {
    event.preventDefault();
    if (cadastrandoGerente) return;
    setErroCadastroGerente("");
    if (!farmaciaGerente) {
      setErroCadastroGerente("Selecione uma farmácia cadastrada.");
      return;
    }
    const gerente = {
      nomeGerente,
      emailGerente,
      cpfGerente,
      crfGerente,
      // sem senha: o back gera a provisória e manda por e-mail com a matrícula
      cepGerente,
      enderecoGerente,
      numeroGerente,
      complementoGerente: complementoGerente || null,
      bairroGerente,
      cidadeGerente,
      ufGerente,
      fkIdFarmacia: Number(farmaciaGerente.idFarmacia),
    };
    setCadastrandoGerente(true);

    try {
      const response = await fetch(`${API_URL}/gerente`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(gerente),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Erro ao cadastrar gerente");
      }

      const [novoGerente] = normalizeGerentes([{
        ...gerente,
        ...result.recebido,
        nomeFarmacia: farmaciaGerente.nomeFarmacia,
      }]);
      // cadastro novo entra no topo da lista
      setData((current) => ({ ...current, gerentes: [novoGerente, ...current.gerentes] }));

      // a senha é gerada pelo back e vai por e-mail junto com a matrícula
      setNotice(
        result.email?.status === "falhou"
          ? `${nomeGerente}: cadastrado, mas o e-mail não foi enviado. Entregue pessoalmente a matrícula ${result.matricula} e a senha provisória ${result.senhaProvisoria}.`
          : `${nomeGerente}: cadastrado! A matrícula e a senha provisória foram enviadas para ${emailGerente}.`,
      );
      setModal(null);

      // Limpa os campos depois do cadastro
      setNomeGerente("");
      setEmailGerente("");
      setCpfGerente("");
      setCrfGerente("");
      setCepGerente("");
      setEnderecoGerente("");
      setNumeroGerente("");
      setComplementoGerente("");
      setBairroGerente("");
      setCidadeGerente("");
      setUfGerente("");
      setFarmaciaGerente(null);
    } catch (error) {
      console.error("Erro ao cadastrar gerente:", error);

      setNotice(`Erro ao cadastrar gerente: ${error.message}`);
      setErroCadastroGerente(error.message);
    } finally {
      setCadastrandoGerente(false);
    }
  }

  function openEditFarmacia(record) {
    const farmacia = data.farmacias.find(
      (item) => String(item.id) === String(record.id),
    );

    setNomeFarmacia(farmacia?.name || record.name || "");
    setEmailFarmacia(farmacia?.email || record.email || "");
    setTelFarmacia(farmacia?.phone || record.phone || "");
    setCnesFarmacia(farmacia?.cnes || record.cnes || "");
    setCepFarmacia(farmacia?.cepFarmacia || "");
    setEnderecoFarmacia(farmacia?.enderecoFarmacia || "");
    setNumeroFarmacia(farmacia?.numeroFarmacia || "");
    setComplementoFarmacia(farmacia?.complementoFarmacia || "");
    setBairroFarmacia(farmacia?.bairroFarmacia || "");
    setCidadeFarmacia(farmacia?.cidadeFarmacia || farmacia?.unit || "");
    setUfFarmacia(farmacia?.ufFarmacia || "");
    setModal({ type: "editFarmacia", record: farmacia || record });
  }

  async function updateFarmacia(event) {
    event.preventDefault();

    const farmacia = {
      nomeFarmacia,
      emailFarmacia,
      telFarmacia,
      cnesFarmacia,
      cepFarmacia,
      enderecoFarmacia,
      numeroFarmacia,
      complementoFarmacia: complementoFarmacia || null,
      bairroFarmacia,
      cidadeFarmacia,
      ufFarmacia,
    };

    try {
      const response = await fetch(
        `${API_URL}/farmacia/${encodeURIComponent(modal.record.id)}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify(farmacia),
        },
      );

      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorMessage =
          (typeof result.error === "string" ? result.error : null) ||
          result.message ||
          result.error?.message ||
          result.error?.errstr ||
          "Erro ao atualizar farmácia";
        throw new Error(errorMessage);
      }

      const [updatedFarmacia] = normalizeFarmacias([{
        ...farmacia, idFarmacia: modal.record.id, idEndereco: modal.record.idEndereco,
      }]);

      setData((current) => ({
        ...current,
        farmacias: current.farmacias.map((item) =>
          String(item.id) === String(modal.record.id)
            ? {
                ...item,
                ...updatedFarmacia,
              }
            : item,
        ),
      }));

      setNotice(`${nomeFarmacia}: atualizada com sucesso!`);
      setModal(null);
      resetFarmaciaFields();
    } catch (error) {
      console.error("Erro ao atualizar farmácia:", error);
      setNotice(`Erro ao atualizar farmácia: ${error.message}`);
    }
  }

  function resetFarmaciaFields() {
    setNomeFarmacia("");
    setEmailFarmacia("");
    setTelFarmacia("");
    setCnesFarmacia("");
    setCepFarmacia("");
    setEnderecoFarmacia("");
    setNumeroFarmacia("");
    setComplementoFarmacia("");
    setBairroFarmacia("");
    setCidadeFarmacia("");
    setUfFarmacia("");
  }

  async function registerFarmacia(event) {
    event.preventDefault();

    const farmacia = {
      nomeFarmacia,
      emailFarmacia,
      telFarmacia,
      cnesFarmacia,
      cepFarmacia,
      enderecoFarmacia,
      numeroFarmacia,
      complementoFarmacia: complementoFarmacia || null,
      bairroFarmacia,
      cidadeFarmacia,
      ufFarmacia,
    };

    try {
      const response = await fetch(`${API_URL}/farmacia`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(farmacia),
      });

      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorMessage =
          (typeof result.error === "string" ? result.error : null) ||
          result.message ||
          result.error?.message ||
          result.error?.errstr ||
          "Erro ao cadastrar farmácia";
        throw new Error(errorMessage);
      }

      const [nextFarmacia] = normalizeFarmacias([{ ...farmacia, ...result.recebido }]);

      setData((current) => ({
        ...current,
        farmacias: [nextFarmacia, ...current.farmacias],
      }));
      setNotice(`${nomeFarmacia}: cadastrada com sucesso!`);
      setModal(null);

      resetFarmaciaFields();
    } catch (error) {
      console.error("Erro ao cadastrar farmácia:", error);
      setNotice(`Erro ao cadastrar farmácia: ${error.message}`);
    }
  }
  const statNoun = {
    gerentes: { total: "gerentes", active: "Gerentes ativos" },
    farmacias: { total: "farmácias", active: "Farmácias ativas" },
    pacientes: { total: "pacientes", active: "Pacientes ativos" },
  }[section] || { total: config.label.toLowerCase(), active: "Ativos" };

  const rowActionLabel = managers ? "Excluir" : tickets ? "Banir" : "Bloquear";

  return (
    <>
      {crud ? (
        <>
          <header className="mgr-page-head adm-hero2">
            <div>
              <h1>{config.label}</h1>
              <p>{config.description}</p>
            </div>
            <div className="adm-hero2-actions">
              <button
                type="button"
                className="adm-hero2-export"
                onClick={exportCsv}
              >
                <Icon name="download" size={15} /> Exportar
              </button>
              {managers && (
                <button data-track="cadastrar-gerente"
                  className="mgr-primary"
                  onClick={() => {
                    setFarmaciaGerente(null);
                    setErroCadastroGerente("");
                    setModal({ type: "register" });
                  }}
                >
                  Cadastrar gerente
                </button>
              )}
              {pharmacies && (
                <button data-track="cadastrar-farmacia"
                  className="mgr-primary"
                  onClick={() => setModal({ type: "registerFarmacia" })}
                >
                  Cadastrar farmácia
                </button>
              )}
            </div>
          </header>

          <div className="adm-stats-row">
            <div className="adm-stat-card">
              <span className="adm-stat-icon" aria-hidden="true">
                <PersonaIcon
                  role={
                    managers ? "gerente" : patients ? "paciente" : "funcionario"
                  }
                  size={20}
                />
              </span>
              <div>
                <p>Total de {statNoun.total}</p>
                <strong>{records.length}</strong>
              </div>
            </div>
            <div className="adm-stat-card">
              <span className="adm-stat-icon is-check" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m5 13 4 4L19 7" /></svg>
              </span>
              <div>
                <p>{statNoun.active}</p>
                <strong>{activeCount}</strong>
              </div>
            </div>
          </div>

          {notice && (
            <p className="adm-notice" role="status">
              {notice}
            </p>
          )}

          <section className="mgr-panel adm-panel2" aria-labelledby="adm-list-title">
            <div className="adm-toolbar2">
              <label className="adm-search2">
                <Icon name="search" size={15} />
                <input
                  type="search"
                  aria-label={`Buscar ${config.label.toLowerCase()}`}
                  placeholder="Buscar por nome, e-mail ou unidade…"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                />
              </label>
              <select
                aria-label="Filtrar por unidade"
                value={unitFilter}
                onChange={(event) => setUnitFilter(event.target.value)}
              >
                <option value="">Todas as unidades</option>
                {unitOptions.map((unit) => (
                  <option key={unit} value={unit}>
                    {unit}
                  </option>
                ))}
              </select>
              <select
                aria-label="Filtrar por situação"
                value={status}
                onChange={(event) => setStatus(event.target.value)}
              >
                <option value="">Todos os status</option>
                {(managers ? ["Ativo"] : ["Ativo", "Bloqueado"]).map(
                  (value) => (
                    <option key={value}>{value}</option>
                  ),
                )}
              </select>
            </div>
            {managers || patients ? (
              <GradePessoas rotulo={config.label}>
                {paginated.map((record) => {
                  const blocked = ["Bloqueado", "Banido"].includes(record.status);
                  return (
                    <li key={record.id}>
                      <CartaoPessoa
                        role={managers ? "gerente" : "paciente"}
                        nome={record.name}
                        foto={record.photo}
                        papel={managers ? ["Gerente", record.crf].filter(Boolean).join(" · ") : "Paciente"}
                        // só mostra a situação quando foge do normal (todos ativos = nenhum selo)
                        selo={blocked ? <span className="mgr-badge red">{record.status}</span> : null}
                        linhas={[
                          ["pharmacy", managers ? record.unit : null],
                          ["map", patients && record.unit !== "Unidade não informada" ? record.unit : null],
                          ["mail", record.email],
                          ["phone", record.phone],
                        ]}
                        onAbrir={(el) => abrirPerfil(tipoPerfil, record.id, el)}
                        acoes={(
                          <div className="adm-row-menu-wrap">
                            <button
                              type="button"
                              className="adm-row-menu-trigger"
                              aria-label={`Mais ações: ${record.name}`}
                              aria-expanded={openRowMenu === record.id}
                              onClick={() => setOpenRowMenu((current) => (current === record.id ? null : record.id))}
                            >
                              <Icon name="dots" size={16} />
                            </button>
                            {openRowMenu === record.id && (
                              <>
                                <div data-sem-perfil className="adm-menu-backdrop" onClick={() => setOpenRowMenu(null)} />
                                <div className="adm-row-menu" role="menu">
                                  <button
                                    type="button"
                                    role="menuitem"
                                    onClick={(event) => {
                                      setOpenRowMenu(null);
                                      abrirPerfil(tipoPerfil, record.id, event.currentTarget.closest("article"));
                                    }}
                                  >
                                    Consultar
                                  </button>
                                  <button
                                    type="button"
                                    role="menuitem"
                                    className="is-danger"
                                    disabled={blocked}
                                    onClick={() => {
                                      setModal({ type: "confirm", record });
                                      setOpenRowMenu(null);
                                    }}
                                  >
                                    {rowActionLabel}
                                  </button>
                                </div>
                              </>
                            )}
                          </div>
                        )}
                      />
                    </li>
                  );
                })}
              </GradePessoas>
            ) : (
              <div className="mgr-table-wrap">
                <table className="adm-table2">
                  <thead>
                    <tr>
                      <th scope="col">Nome</th>
                      <th scope="col">{pharmacies ? "Cidade" : "Unidade"}</th>
                      <th scope="col">Situação</th>
                      <th scope="col"><span className="sr-only">Ações</span></th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginated.map((record) => {
                      const blocked = ["Bloqueado", "Banido"].includes(
                        record.status,
                      );
                      return (
                        <tr
                          key={record.id}
                          {...propsLinha((el) => abrirPerfil(tipoPerfil, record.id, el), `Abrir perfil de ${record.name}`)}
                        >
                          <td>
                            <div className="adm-name-cell">
                              {pharmacies && record.photo ? (
                                <span className="adm-avatar-circle pharmacy-avatar perfil-avatar-lista">
                                  <img src={record.photo} alt="" />
                                </span>
                              ) : pharmacies ? <span
                                className="adm-avatar-circle pharmacy-avatar"
                                aria-hidden="true"
                              >
                                <Icon name="pharmacy" size={20} />
                              </span> : <PersonaAvatar role={managers ? "gerente" : patients ? "paciente" : "funcionario"} photo={record.photo} name={record.name} />}
                              <span>
                                <strong>{record.name}</strong>
                                <small>
                                  {record.email ||
                                    `Código: ${record.id.toUpperCase()}`}
                                </small>
                              </span>
                            </div>
                          </td>
                          <td>{record.unit}</td>
                          <td>
                            <span
                              className={`mgr-badge ${blocked ? "red" : "green"}`}
                            >
                              {record.status}
                            </span>
                          </td>
                          <td>
                            <div className="adm-row-menu-wrap">
                              <button
                                type="button"
                                className="adm-row-menu-trigger"
                                aria-label={`Mais ações: ${record.name}`}
                                aria-expanded={openRowMenu === record.id}
                                onClick={() =>
                                  setOpenRowMenu((current) =>
                                    current === record.id ? null : record.id,
                                  )
                                }
                              >
                                <Icon name="dots" size={16} />
                              </button>
                              {openRowMenu === record.id && (
                                <>
                                  <div
                                    data-sem-perfil
                                    className="adm-menu-backdrop"
                                    onClick={() => setOpenRowMenu(null)}
                                  />
                                  <div className="adm-row-menu" role="menu">
                                    <button
                                      type="button"
                                      role="menuitem"
                                      onClick={(event) => {
                                        setOpenRowMenu(null);
                                        abrirPerfil(tipoPerfil, record.id, event.currentTarget.closest("tr"));
                                      }}
                                    >
                                      Consultar
                                    </button>
                                    {pharmacies && (
                                      <button
                                        type="button"
                                        role="menuitem"
                                        onClick={() => {
                                          openEditFarmacia(record);
                                          setOpenRowMenu(null);
                                        }}
                                      >
                                        Editar
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      role="menuitem"
                                      className="is-danger"
                                      disabled={blocked}
                                      onClick={() => {
                                        setModal({ type: "confirm", record });
                                        setOpenRowMenu(null);
                                      }}
                                    >
                                      {rowActionLabel}
                                    </button>
                                  </div>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            {!filtered.length && (
              <p className="mgr-empty">
                Nenhum registro encontrado. Tente outra busca ou situação.
              </p>
            )}
            <div className="adm-pagination">
              <p className="mgr-table-note" role="status">
                {pageStart}–{pageEnd} de {filtered.length} registros
              </p>
              {totalPages > 1 && (
                <div className="adm-pager">
                  <button
                    type="button"
                    className="adm-pager-btn"
                    disabled={currentPage === 1}
                    aria-label="Página anterior"
                    onClick={() => setPage((value) => Math.max(1, value - 1))}
                  >
                    <Icon name="chevronLeft" size={15} />
                  </button>
                  {Array.from({ length: totalPages }, (_, index) => index + 1).map(
                    (number) => (
                      <button
                        key={number}
                        type="button"
                        className={`adm-pager-btn${number === currentPage ? " is-active" : ""}`}
                        aria-current={number === currentPage ? "page" : undefined}
                        onClick={() => setPage(number)}
                      >
                        {number}
                      </button>
                    ),
                  )}
                  <button
                    type="button"
                    className="adm-pager-btn"
                    disabled={currentPage === totalPages}
                    aria-label="Próxima página"
                    onClick={() =>
                      setPage((value) => Math.min(totalPages, value + 1))
                    }
                  >
                    <Icon name="chevronRight" size={15} />
                  </button>
                </div>
              )}
            </div>
          </section>
        </>
      ) : (
        <>
          <header className="mgr-page-head">
            <div>
              <h1>{config.title}</h1>
              <p>{config.description}</p>
            </div>
          </header>
          <div className="adm-overview">
            <span>
              <strong>{records.length}</strong> {config.label.toLowerCase()} na
              rede
            </span>
            <span>
              <strong>{restricted}</strong> {tickets ? "banidos" : "bloqueados"}
            </span>
          </div>
          {notice && (
            <p className="adm-notice" role="status">
              {notice}
            </p>
          )}
          <section className="mgr-panel" aria-labelledby="adm-list-title">
            <div className="mgr-toolbar">
              <h2 id="adm-list-title">
                {config.label}{" "}
                <span className="mgr-badge">{records.length}</span>
              </h2>
              <input
                type="search"
                aria-label={`Buscar ${config.label.toLowerCase()}`}
                placeholder="Buscar chamado ou unidade…"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
              <select
                aria-label="Filtrar por situação"
                value={status}
                onChange={(event) => setStatus(event.target.value)}
              >
                <option value="">Todas as situações</option>
                {["Pendente", "Em andamento", "Resolvido", "Banido"].map(
                  (value) => (
                    <option key={value}>{value}</option>
                  ),
                )}
              </select>
            </div>
            <div className="mgr-table-wrap">
              <table>
                <thead>
                  <tr>
                    <th scope="col">Chamado</th>
                    <th scope="col">Unidade</th>
                    <th scope="col">Situação</th>
                    <th scope="col">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((record) => (
                    <tr
                      key={record.id}
                      {...propsLinha(() => setModal({ type: "details", record }), `Consultar ${record.name}`)}
                    >
                      <td>
                        <strong>{record.name}</strong>
                        <small>{formatDate(record.date)}</small>
                      </td>
                      <td>{record.unit}</td>
                      <td>
                        <span
                          className={`mgr-badge ${["Bloqueado", "Banido"].includes(record.status) ? "red" : record.status === "Pendente" ? "yellow" : "green"}`}
                        >
                          {record.status}
                        </span>
                      </td>
                      <td>
                        <div className="adm-actions">
                          <button
                            className="mgr-text-button"
                            aria-label={`Consultar ${record.name}`}
                            onClick={() =>
                              setModal({ type: "details", record })
                            }
                          >
                            Consultar
                          </button>
                          <button
                            className="adm-danger"
                            disabled={["Bloqueado", "Banido"].includes(
                              record.status,
                            )}
                            aria-label={`${config.action}: ${record.name}`}
                            onClick={() =>
                              setModal({ type: "confirm", record })
                            }
                          >
                            Banir
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {!filtered.length && (
              <p className="mgr-empty">
                Nenhum registro encontrado. Tente outra busca ou situação.
              </p>
            )}
            <p className="mgr-table-note" role="status">
              {filtered.length} de {records.length} registros
            </p>
          </section>
        </>
      )}
      {modal?.type === "editFarmacia" && (
        <Dialog title="Editar farmácia" onClose={() => setModal(null)}>
          <form className="mgr-form" onSubmit={updateFarmacia}>
            <label>
              Nome da farmácia
              <input
                name="nomeFarmacia"
                value={nomeFarmacia}
                onChange={({ target }) => setNomeFarmacia(target.value)}
                required
                minLength={3}
                maxLength={120}
                autoComplete="organization-title"
                placeholder="Nome da farmácia"
              />
            </label>
            <div className="mgr-form-row">
              <label>
                E-mail da farmácia
                <input
                  name="emailFarmacia"
                  value={emailFarmacia}
                  onChange={({ target }) => setEmailFarmacia(target.value)}
                  type="email"
                  required
                  maxLength={254}
                  autoComplete="email"
                  placeholder="farmacia@exemplo.com"
                />
              </label>
              <label>
                Telefone
                <input
                  name="telFarmacia"
                  value={telFarmacia}
                  onChange={({ target }) => setTelFarmacia(target.value)}
                  type="tel"
                  required
                  placeholder="(11) 99999-9999"
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                CNES
                <input
                  name="cnesFarmacia"
                  value={cnesFarmacia}
                  onChange={({ target }) => setCnesFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Número CNES"
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                CEP
                <input
                  name="cepFarmacia"
                  value={cepFarmacia}
                  onChange={({ target }) => setCepFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="00000-000"
                />
              </label>
              <label>
                Endereço
                <input
                  name="enderecoFarmacia"
                  value={enderecoFarmacia}
                  onChange={({ target }) => setEnderecoFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Rua, avenida..."
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                Número
                <input
                  name="numeroFarmacia"
                  value={numeroFarmacia}
                  onChange={({ target }) => setNumeroFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="123"
                />
              </label>
              <label>
                Complemento (opcional)
                <input
                  name="complementoFarmacia"
                  value={complementoFarmacia}
                  onChange={({ target }) =>
                    setComplementoFarmacia(target.value)
                  }
                  type="text"
                  placeholder="Apartamento, bloco..."
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                Bairro
                <input
                  name="bairroFarmacia"
                  value={bairroFarmacia}
                  onChange={({ target }) => setBairroFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Bairro"
                />
              </label>
              <label>
                Cidade
                <input
                  name="cidadeFarmacia"
                  value={cidadeFarmacia}
                  onChange={({ target }) => setCidadeFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Cidade"
                />
              </label>
            </div>
            <label>
              UF
              <input name="ufFarmacia" value={ufFarmacia}
                onChange={({ target }) => setUfFarmacia(target.value.toUpperCase())}
                required maxLength={2} pattern="[A-Za-z]{2}" placeholder="SP" />
            </label>
            <div className="mgr-modal-actions">
              <button
                className="mgr-secondary"
                type="button"
                onClick={() => {
                  resetFarmaciaFields();
                  setModal(null);
                }}
              >
                Cancelar
              </button>
              <button className="mgr-primary" type="submit">
                Salvar
              </button>
            </div>
          </form>
        </Dialog>
      )}
      {modal?.type === "registerFarmacia" && (
        <Dialog title="Cadastrar farmácia" onClose={() => setModal(null)}>
          <form className="mgr-form" onSubmit={registerFarmacia}>
            <label>
              Nome da farmácia
              <input
                name="nomeFarmacia"
                value={nomeFarmacia}
                onChange={({ target }) => setNomeFarmacia(target.value)}
                required
                minLength={3}
                maxLength={120}
                autoComplete="organization-title"
                placeholder="Nome da farmácia"
              />
            </label>
            <div className="mgr-form-row">
              <label>
                E-mail da farmácia
                <input
                  name="emailFarmacia"
                  value={emailFarmacia}
                  onChange={({ target }) => setEmailFarmacia(target.value)}
                  type="email"
                  required
                  maxLength={254}
                  autoComplete="email"
                  placeholder="farmacia@exemplo.com"
                />
              </label>
              <label>
                Telefone
                <input
                  name="telFarmacia"
                  value={telFarmacia}
                  onChange={({ target }) => setTelFarmacia(target.value)}
                  type="tel"
                  required
                  placeholder="(11) 99999-9999"
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                CNES
                <input
                  name="cnesFarmacia"
                  value={cnesFarmacia}
                  onChange={({ target }) => setCnesFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Número CNES"
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                CEP
                <input
                  name="cepFarmacia"
                  value={cepFarmacia}
                  onChange={({ target }) => setCepFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="00000-000"
                />
              </label>
              <label>
                Endereço
                <input
                  name="enderecoFarmacia"
                  value={enderecoFarmacia}
                  onChange={({ target }) => setEnderecoFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Rua, avenida..."
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                Número
                <input
                  name="numeroFarmacia"
                  value={numeroFarmacia}
                  onChange={({ target }) => setNumeroFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="123"
                />
              </label>
              <label>
                Complemento (opcional)
                <input
                  name="complementoFarmacia"
                  value={complementoFarmacia}
                  onChange={({ target }) =>
                    setComplementoFarmacia(target.value)
                  }
                  type="text"
                  placeholder="Apartamento, bloco..."
                />
              </label>
            </div>
            <div className="mgr-form-row">
              <label>
                Bairro
                <input
                  name="bairroFarmacia"
                  value={bairroFarmacia}
                  onChange={({ target }) => setBairroFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Bairro"
                />
              </label>
              <label>
                Cidade
                <input
                  name="cidadeFarmacia"
                  value={cidadeFarmacia}
                  onChange={({ target }) => setCidadeFarmacia(target.value)}
                  type="text"
                  required
                  placeholder="Cidade"
                />
              </label>
            </div>
            <label>
              UF
              <input name="ufFarmacia" value={ufFarmacia}
                onChange={({ target }) => setUfFarmacia(target.value.toUpperCase())}
                required maxLength={2} pattern="[A-Za-z]{2}" placeholder="SP" />
            </label>
            <div className="mgr-modal-actions">
              <button
                className="mgr-secondary"
                type="button"
                onClick={() => setModal(null)}
              >
                Cancelar
              </button>
              <button className="mgr-primary" type="submit">
                Cadastrar farmácia
              </button>
            </div>
          </form>
        </Dialog>
      )}
      {modal?.type === "register" && (
        <Dialog title="Cadastrar gerente" onClose={() => setModal(null)}>
          <form className="mgr-form" onSubmit={register}>
            <FarmaciaSelect value={farmaciaGerente} onChange={setFarmaciaGerente} />
            <label>
              Nome completo
              <input
                name="name"
                value={nomeGerente}
                onChange={({ target }) => setNomeGerente(target.value)}
                required
                minLength={3}
                maxLength={120}
                autoComplete="name"
                placeholder="Nome do gerente"
              />
            </label>
            <label>
              E-mail
              <input
                name="email"
                value={emailGerente}
                onChange={({ target }) => setEmailGerente(target.value)}
                type="email"
                required
                maxLength={254}
                autoComplete="email"
                placeholder="gerente@exemplo.com"
              />
            </label>

            <div className="mgr-form-row">
              <label>
                CPF
                <input
                  name="cpfGerente"
                  value={cpfGerente}
                  onChange={({ target }) => setCpfGerente(target.value)}
                  type="text"
                  required
                  // autoComplete="new-password"
                  placeholder="XXX.XXX.XXX-XX"
                  onInput={(event) => event.currentTarget.setCustomValidity("")}
                />
              </label>
              <label>
                CRF (Conselho Regional de Farmácia)
                <input
                  name="crfGerente"
                  value={crfGerente}
                  onChange={({ target }) => setCrfGerente(target.value)}
                  type="text"
                  required
                  // autoComplete="new-password"
                  placeholder="Ex.: 123456"
                  onInput={(event) => event.currentTarget.setCustomValidity("")}
                />
              </label>
            </div>

            <p className="mgr-form-unidade">
              O sistema gera a <strong>matrícula</strong> e uma <strong>senha provisória</strong> e
              manda as duas para o e-mail do gerente.
            </p>

            <label>
              CEP
              <input
                name="cepGerente"
                value={cepGerente}
                onChange={({ target }) => alterarCepGerente(target.value)}
                type="text"
                inputMode="numeric"
                autoComplete="postal-code"
                required
                pattern="\d{5}-?\d{3}"
                placeholder="Ex. 00000-000"
                aria-describedby="cep-gerente-status"
                onInput={(event) => event.currentTarget.setCustomValidity("")}
              />
              <small id="cep-gerente-status" role="status" className="mgr-cep-status">
                {statusCepGerente === "buscando" && "Buscando o endereço…"}
                {statusCepGerente === "nao-encontrado" && "CEP não encontrado. Preencha o endereço abaixo."}
                {statusCepGerente === "erro" && "Não foi possível buscar o CEP. Preencha o endereço abaixo."}
              </small>
            </label>
            <label>
              Endereço
              <input
                name="enderecoGerente"
                value={enderecoGerente}
                onChange={({ target }) => setEnderecoGerente(target.value)}
                type="text"
                required
                // autoComplete="new-password"
                placeholder="Ex. Rua Alcindo Pereira"
                onInput={(event) => event.currentTarget.setCustomValidity("")}
              />
            </label>

            <div className="mgr-form-row">
              <label>
                Nº
                <input
                  ref={numeroGerenteRef}
                  name="numeroGerente"
                  value={numeroGerente}
                  onChange={({ target }) => setNumeroGerente(target.value)}
                  type="text"
                  required
                  // autoComplete="new-password"
                  placeholder="Ex. 45"
                  onInput={(event) => event.currentTarget.setCustomValidity("")}
                />
              </label>
              <label>
                Complemento (opcional)
                <input
                  name="complementoGerente"
                  value={complementoGerente}
                  onChange={({ target }) => setComplementoGerente(target.value)}
                  type="text"
                  // autoComplete="new-password"
                  placeholder="Ex. Apartamento, casa, andar, etc."
                  onInput={(event) => event.currentTarget.setCustomValidity("")}
                />
              </label>
            </div>

            <div className="mgr-form-row">
              <label>
                Bairro
                <input
                  name="bairroGerente"
                  value={bairroGerente}
                  onChange={({ target }) => setBairroGerente(target.value)}
                  type="text"
                  required
                  // autoComplete="new-password"
                  placeholder="Ex. São Paulo"
                  onInput={(event) => event.currentTarget.setCustomValidity("")}
                />
              </label>
              <label>
                Cidade
                <input
                  name="cidadeGerente"
                  value={cidadeGerente}
                  onChange={({ target }) => setCidadeGerente(target.value)}
                  type="text"
                  required
                  // autoComplete="new-password"
                  placeholder="Ex. SP"
                  onInput={(event) => event.currentTarget.setCustomValidity("")}
                />
              </label>
            </div>

            <label>
              UF
              <input name="ufGerente" value={ufGerente}
                onChange={({ target }) => setUfGerente(target.value.toUpperCase())}
                required maxLength={2} pattern="[A-Za-z]{2}" placeholder="SP" />
            </label>
            {erroCadastroGerente && <p role="alert">{erroCadastroGerente}</p>}
            <div className="mgr-modal-actions">
              <button
                className="mgr-secondary"
                type="button"
                onClick={() => setModal(null)}
              >
                Cancelar
              </button>
              <button className="mgr-primary" type="submit" disabled={cadastrandoGerente || !farmaciaGerente}>
                {cadastrandoGerente ? "Cadastrando…" : "Cadastrar gerente"}
              </button>
            </div>
          </form>
        </Dialog>
      )}
      {modal?.type === "details" && (
        <Dialog title={modal.record.name} onClose={() => setModal(null)}>
          <dl className="adm-details">
            <div>
              <dt>Código</dt>
              <dd>{modal.record.id}</dd>
            </div>
            <div>
              <dt>Unidade</dt>
              <dd>{modal.record.unit}</dd>
            </div>
            <div>
              <dt>Situação</dt>
              <dd>{modal.record.status}</dd>
            </div>
            {modal.record.email && (
              <div>
                <dt>E-mail</dt>
                <dd>{modal.record.email}</dd>
              </div>
            )}
            {modal.record.role && (
              <div>
                <dt>Cargo</dt>
                <dd>{modal.record.role}</dd>
              </div>
            )}
            {modal.record.shift && (
              <div>
                <dt>Turno</dt>
                <dd>{modal.record.shift}</dd>
              </div>
            )}
            {pharmacies && (
              <>
                <div>
                  <dt>Gerente responsável</dt>
                  <dd>
                    {(() => {
                      const managers = data.gerentes.filter(
                        (item) =>
                          String(item.farmaciaId) === String(modal.record.id),
                      );
                      return managers.map((manager) => manager.name).join(", ") || "Não informado";
                    })()}
                  </dd>
                </div>
                <div>
                  <dt>Telefone</dt>
                  <dd>{modal.record.phone || "Não informado"}</dd>
                </div>
                <div>
                  <dt>CNES</dt>
                  <dd>{modal.record.cnes || "Não informado"}</dd>
                </div>
                <div>
                  <dt>E-mail</dt>
                  <dd>{modal.record.email || "Não informado"}</dd>
                </div>
              </>
            )}
            {managers && (
              <>
                <div className="adm-manager-unit-panel">
                  <dt className="adm-manager-panel-title">
                    Farmácia gerenciada
                  </dt>
                  <dd>
                    {managerFarmacias.length ? (
                      <div className="adm-manager-unit-card">
                        <strong className="adm-manager-unit-name">
                          {managerFarmacias
                            .map((farmacia) => farmacia.name)
                            .join(", ")}
                        </strong>
                        <span className="adm-manager-unit-meta">
                          {managerFarmacias
                            .map((farmacia) => farmacia.unit)
                            .filter(Boolean)
                            .join(" · ") || "Unidade não informada"}
                        </span>
                      </div>
                    ) : (
                      "Não informado"
                    )}
                  </dd>
                </div>
                <div className="adm-manager-unit-panel">
                  <dt className="adm-manager-panel-title">
                    Funcionários da unidade
                  </dt>
                  <dd>
                    {managerFuncionarios.length ? (
                      <ul className="adm-manager-employee-list">
                        {managerFuncionarios.map((funcionario) => (
                          <li
                            key={funcionario.id}
                            className="adm-manager-employee-card"
                          >
                            <span className="adm-manager-employee-name">
                              {funcionario.name}
                            </span>
                            <span className="adm-manager-employee-role">
                              {funcionario.role || "Funcionário"}
                            </span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      "Não informado"
                    )}
                  </dd>
                </div>
                <div>
                  <dt>Funcionário vinculado</dt>
                  <dd>
                    {(data.funcionarios || []).find(
                      (employee) => employee.id === modal.record.employeeId,
                    )?.name || "Não informado"}
                  </dd>
                </div>
                <div>
                  <dt>Data de criação</dt>
                  <dd>
                    {modal.record.createdAt
                      ? new Date(modal.record.createdAt).toLocaleString("pt-BR")
                      : "Não informada"}
                  </dd>
                </div>
              </>
            )}
            {tickets && (
              <>
                <div>
                  <dt>Data</dt>
                  <dd>{formatDate(modal.record.date)}</dd>
                </div>
                <div>
                  <dt>Prioridade</dt>
                  <dd>{modal.record.priority}</dd>
                </div>
                <div>
                  <dt>Descrição</dt>
                  <dd>{modal.record.description}</dd>
                </div>
              </>
            )}
          </dl>
          <button className="mgr-secondary" onClick={() => setModal(null)}>
            Fechar
          </button>
        </Dialog>
      )}
      {modal?.type === "confirm" && (
        <Dialog title={config.action} onClose={() => setModal(null)}>
          <p>
            Deseja {managers ? "excluir" : tickets ? "banir" : "bloquear"}{" "}
            <strong>{modal.record.name}</strong>?
          </p>
          <p className="adm-hint">
            Esta ação altera apenas os dados da demonstração. Ao recarregar a
            página, os dados iniciais são restaurados.
          </p>
          <div className="mgr-modal-actions">
            <button
              className="mgr-secondary"
              onClick={() => setModal(null)}
              autoFocus
            >
              Cancelar
            </button>
            <button className="adm-danger adm-confirm" onClick={confirmAction}>
              {config.action}
            </button>
          </div>
        </Dialog>
      )}
    </>
  );
}
