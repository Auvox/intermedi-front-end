import { useCallback, useState } from "react";
import { DirectoryStats } from "../components/Directory";
import { ErroComRetry } from "../components/Chamados";
import CartaoChamado from "../components/CartaoChamado";
import SolicitarReposicao from "../components/SolicitarReposicao";
import { usePerfil } from "../components/perfil/perfilContext";
import useApiList from "../hooks/useApiList";
import useAcaoDaUrl from "../hooks/useAcaoDaUrl";
import { INTERVALO_CHAMADOS, useFuncionarioAtual, usePolling } from "../hooks/useChamados";
import { listarChamadosFuncionario, listarRemedios } from "../services/api";
import { INTERVALO_A_CAMINHO, STATUS_CHAMADO, temACaminho } from "../services/chamados";
import { SkeletonTabela } from "../components/Skeleton";

// "Minhas solicitações": chamados de reposição abertos pelo funcionário.
export default function EmployeeTickets() {
  const funcionario = useFuncionarioAtual();
  const { abrirPerfil } = usePerfil();
  const { idFuncionario } = funcionario;
  const [status, setStatus] = useState("");
  const [solicitando, setSolicitando] = useState(false);
  const { items: medicines } = useApiList(listarRemedios);
  // atalho "Pedir reposição" da visão geral
  useAcaoDaUrl("solicitar", useCallback(() => setSolicitando(true), []), Boolean(idFuncionario && medicines.length));

  const fetcher = useCallback(
    (options) => listarChamadosFuncionario(idFuncionario, status, options).then((data) => data.chamados ?? []),
    [idFuncionario, status],
  );
  const { data, loading, error, reload, retry } = usePolling(fetcher, {
    enabled: Boolean(idFuncionario),
    // a cada 5 s enquanto houver remédio a caminho, para trocar para "Recebido" sozinho
    interval: (lista) => (temACaminho(lista ?? []) ? INTERVALO_A_CAMINHO : INTERVALO_CHAMADOS),
  });
  // Filtra também no cliente para não mostrar a lista anterior (outro status ou
  // outro funcionário) enquanto a nova chega
  const todos = (data ?? []).filter((c) => String(c.funcionario?.idFuncionario) === String(idFuncionario));
  const chamados = todos.filter((c) => !status || c.status === status);

  return (
    <>
      <header className="mgr-page-head">
        <div>
          <h1>Minhas solicitações</h1>
          <p>Acompanhe os pedidos de reposição enviados ao gerente e veja a resposta.</p>
        </div>
        <button data-track="pedir-reposicao"
          type="button"
          className="mgr-primary"
          disabled={!idFuncionario || !medicines.length}
          onClick={() => setSolicitando(true)}
        >
          Solicitar reposição
        </button>
      </header>

      {!idFuncionario ? (
        <section className="mgr-panel">
          {funcionario.loading ? (
            <SkeletonTabela rotulo="Carregando funcionários…" foto={false} />
          ) : (
            <p className="mgr-empty" role="alert">
              {funcionario.error || "Nenhum funcionário cadastrado na API."}
            </p>
          )}
        </section>
      ) : (
        <>
          {!status && data && (
            <DirectoryStats
              items={[
                ["Solicitações", todos.length, "ticket"],
                ["Pendentes", todos.filter((c) => c.status === "pendente").length, "clock"],
                ["Respondidas", todos.filter((c) => c.resposta).length, "check"],
              ]}
            />
          )}
          <section className="mgr-panel" aria-labelledby="emp-chamados-title">
            <div className="mgr-toolbar">
              <h2 id="emp-chamados-title">Solicitações</h2>
              <label className="chamado-filter">
                <span>Status</span>
                <select value={status} onChange={(e) => setStatus(e.target.value)}>
                  <option value="">Todos</option>
                  {Object.entries(STATUS_CHAMADO).map(([valor, { label }]) => (
                    <option key={valor} value={valor}>{label}</option>
                  ))}
                </select>
              </label>
              <button type="button" className="directory-row-action" onClick={reload}>Atualizar</button>
            </div>
            {loading ? (
              <SkeletonTabela rotulo="Carregando solicitações…" foto={false} />
            ) : error && !data ? (
              <ErroComRetry message={error} onRetry={retry} />
            ) : (
              <>
                {error && <p className="chamado-inline-error" role="alert">{error}</p>}
                {chamados.length ? (
                  <ul className="chamado-list">
                    {chamados.map((c) => (
                      <li key={c.idChamado}>
                        <CartaoChamado chamado={c} onAbrir={(chamado, el) => abrirPerfil("chamado", chamado.idChamado, el)} />
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mgr-empty">
                    {status === "pendente"
                      ? "Nenhuma solicitação pendente."
                      : status
                        ? "Nenhuma solicitação com este status."
                        : "Você ainda não fez nenhuma solicitação."}
                  </p>
                )}
                <p className="mgr-table-note">
                  {chamados.length} solicitações · Atualiza automaticamente (a cada 5 s enquanto há remédio a caminho)
                </p>
              </>
            )}
          </section>
        </>
      )}

      {solicitando && (
        <SolicitarReposicao
          medicines={medicines}
          funcionario={funcionario}
          onClose={() => setSolicitando(false)}
          onSuccess={reload}
        />
      )}
    </>
  );
}
